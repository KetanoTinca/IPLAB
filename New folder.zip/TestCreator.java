import java.util.Vector;

public class TestCreator {

  public String titlu;

  public String visibility;

  public String description;

  public ArrayList<Question> questions;

    public Vector  myGame;
    public Vector  myQuestion;

  public void createTest() {
  }

  public void setTitlu( String) {
  }

  public void setVisibility( String) {
  }

  public void setQuestion( Question) {
  }

  public String getQuestion() {
  return null;
  }

}