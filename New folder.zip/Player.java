import java.util.Vector;

public class Player {

  public String nume;

  public Integer scor;

  public Integer pin;

    public Vector  myLogIn;
    public Vector  myNameGenerator;
    public Vector  myGame;

  public void setNume( nume) {
  }

  public String getNume() {
  return null;
  }

  public void startTest( pin) {
  }

}