import java.util.Vector;

public class Game {

  public ArrayList<Player> players;

  public Integer gameCode;

    public Vector  myTestCreator;
    public Vector  myPlayer;

  public void setPlayers( players) {
  }

  public void setScot( Interger) {
  }

  private void createTop() {
  }

}