import java.util.Vector;

public class NameGenerator {

  public String nume;

    public Vector  myPlayer;

  public void setNume( String) {
  }

}