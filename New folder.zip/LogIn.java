import java.util.Vector;

public class LogIn {

  public String nume;

  public String parola;

    public Vector  myPlayer;

  public void setNume( nume) {
  }

  public String setParola( nume) {
  return null;
  }

}