import java.util.Vector;

public class Question {

  public String question;

  public ArrayList<String> answer;

    public Vector  myTestCreator;

  public void setQuestion( question) {
  }

  public String getQuestion() {
  return null;
  }

  public void setAnswer( ArrayList<String>) {
  }

  public String getAnswer() {
  return null;
  }

}